"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Printer, X, Check, RotateCcw, Clock } from "lucide-react"
import { useEffect, useState } from "react"

interface Order {
  id: string
  customer: string
  filename: string
  time: string
  timestamp: number // Add timestamp field
  size: string
  sided: string
  color: string
  copies: number
  pages: number
  price: number
  status: string
  printed: boolean
}

interface OrderRowProps {
  order: Order
  onPrint: (orderId: string) => void
  onDelete: (orderId: string) => void
  onCollect: (orderId: string) => void
  onUndoPrint: (orderId: string) => void
}

function getElapsedTime(timestamp: number): string {
  const now = Date.now()
  const diff = now - timestamp
  const seconds = Math.floor(diff / 1000)
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (seconds < 60) return `${seconds}s ago`
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  return `${days}d ago`
}

export function OrderRow({ order, onPrint, onDelete, onCollect, onUndoPrint }: OrderRowProps) {
  const [elapsedTime, setElapsedTime] = useState(getElapsedTime(order.timestamp))

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsedTime(getElapsedTime(order.timestamp))
    }, 1000) // Update every second

    return () => clearInterval(interval)
  }, [order.timestamp])

  const isDefaultSettings = order.size === "A4" && order.sided === "Single-Sided" && order.color === "Black & White"

  return (
    <div className="flex items-center gap-3 border-b px-4 py-3 transition-colors hover:bg-muted/50">
      {/* Time */}
      <div className="flex shrink-0 items-center gap-1.5 w-20">
        <Clock className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-xs font-medium text-muted-foreground">{elapsedTime}</span>
      </div>

      {/* Customer & File Info */}
      <div className="min-w-0 flex-1">
        {isDefaultSettings ? (
          <div className="flex items-center gap-2">
            <span className="truncate font-medium text-sm">{order.customer}</span>
            <span className="text-muted-foreground">•</span>
            <span className="truncate text-sm text-muted-foreground">{order.filename}</span>
            <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0">
              <ExternalLink className="h-3 w-3" />
            </Button>
            <span className="text-muted-foreground">•</span>
            <span className="text-xs text-muted-foreground whitespace-nowrap">
              {order.copies} copies • {order.pages} pages
            </span>
            <span className="text-muted-foreground">•</span>
            <span className="text-xs font-medium whitespace-nowrap">₹{order.price}</span>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2">
              <span className="truncate font-medium text-sm">{order.customer}</span>
              <span className="text-muted-foreground">•</span>
              <span className="truncate text-sm text-muted-foreground">{order.filename}</span>
              <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0">
                <ExternalLink className="h-3 w-3" />
              </Button>
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <Badge variant={order.color === "Color" ? "default" : "secondary"} className="h-5 text-xs">
                {order.color}
              </Badge>
              <span>•</span>
              <span>{order.size}</span>
              <span>•</span>
              <span>{order.sided}</span>
              <span>•</span>
              <span>
                {order.copies} copies • {order.pages} pages
              </span>
              <span>•</span>
              <span className="font-medium">₹{order.price}</span>
            </div>
          </>
        )}
      </div>

      {/* Actions */}
      <div className="flex shrink-0 items-center gap-2">
        {order.printed && (
          <Button variant="outline" size="sm" onClick={() => onUndoPrint(order.id)} className="h-8 text-xs">
            <RotateCcw className="mr-1 h-3 w-3" />
            Undo
          </Button>
        )}

        {!order.printed && (
          <Button size="sm" onClick={() => onPrint(order.id)} className="h-8 bg-green-600 text-xs hover:bg-green-700">
            <Printer className="mr-1 h-3 w-3" />
            Print
          </Button>
        )}

        <Button variant="destructive" size="icon" onClick={() => onDelete(order.id)} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>

        {order.status === "pending" ? (
          <Button size="sm" onClick={() => onCollect(order.id)} className="h-8 w-20 text-xs">
            Collect
          </Button>
        ) : (
          <Badge variant="secondary" className="h-8 w-20 justify-center">
            <Check className="mr-1 h-3 w-3" />
            Done
          </Badge>
        )}
      </div>
    </div>
  )
}
