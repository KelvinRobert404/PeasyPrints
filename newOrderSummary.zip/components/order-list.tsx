"use client"

import { useVirtualizer } from "@tanstack/react-virtual"
import { useRef } from "react"
import { OrderRow } from "./order-row"

interface Order {
  id: string
  customer: string
  filename: string
  time: string
  size: string
  sided: string
  color: string
  copies: number
  pages: number
  price: number
  status: string
  printed: boolean
}

interface OrderListProps {
  orders: Order[]
  onPrint: (orderId: string) => void
  onDelete: (orderId: string) => void
  onCollect: (orderId: string) => void
  onUndoPrint: (orderId: string) => void
}

export function OrderList({ orders, onPrint, onDelete, onCollect, onUndoPrint }: OrderListProps) {
  const parentRef = useRef<HTMLDivElement>(null)

  const virtualizer = useVirtualizer({
    count: orders.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 80,
    overscan: 5,
  })

  if (orders.length === 0) {
    return <div className="flex h-64 items-center justify-center text-muted-foreground">No orders found</div>
  }

  return (
    <div ref={parentRef} className="h-[600px] overflow-auto">
      <div
        style={{
          height: `${virtualizer.getTotalSize()}px`,
          width: "100%",
          position: "relative",
        }}
      >
        {virtualizer.getVirtualItems().map((virtualRow) => {
          const order = orders[virtualRow.index]
          return (
            <div
              key={virtualRow.key}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: `${virtualRow.size}px`,
                transform: `translateY(${virtualRow.start}px)`,
              }}
            >
              <OrderRow
                order={order}
                onPrint={onPrint}
                onDelete={onDelete}
                onCollect={onCollect}
                onUndoPrint={onUndoPrint}
              />
            </div>
          )
        })}
      </div>
    </div>
  )
}
