"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Search, X, Filter } from "lucide-react"
import { OrderList } from "@/components/order-list"

// Mock data generator
const generateMockOrders = (count: number) => {
  const customers = ["Kelvin Robert", "Sarah Johnson", "Mike Chen", "Emma Wilson", "David Brown"]
  const files = ["TCS ION Fee Collection", "Invoice", "Report", "Document", "Images", "Contract"]
  const colors = ["Color", "Black & White"]
  const statuses = ["pending", "completed", "cancelled"]

  return Array.from({ length: count }, (_, i) => {
    const status = statuses[Math.floor(Math.random() * statuses.length)]
    const timestamp = Date.now() - Math.random() * 86400000 // Random time within last 24 hours
    return {
      id: `order-${i + 1}`,
      customer: customers[Math.floor(Math.random() * customers.length)],
      filename: `${files[Math.floor(Math.random() * files.length)]}_${i + 1}.pdf`,
      time: new Date(timestamp).toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      }),
      timestamp, // Add timestamp field for elapsed time
      size: "A4",
      sided: "Single-Sided",
      color: colors[Math.floor(Math.random() * colors.length)],
      copies: Math.floor(Math.random() * 5) + 1,
      pages: Math.floor(Math.random() * 10) + 1,
      price: Math.floor(Math.random() * 50) + 1,
      status,
      printed: status === "completed" ? true : Math.random() > 0.5,
    }
  })
}

export default function OrderManagement() {
  const [orders, setOrders] = useState(generateMockOrders(100))
  const [searchQuery, setSearchQuery] = useState("")
  const [colorFilter, setColorFilter] = useState<string>("all")
  const [activeTab, setActiveTab] = useState<string>("pending")
  const [searchExpanded, setSearchExpanded] = useState(false)
  const [filterExpanded, setFilterExpanded] = useState(false)

  // Calculate stats
  const stats = useMemo(() => {
    const pending = orders.filter((o) => o.status === "pending").length
    const completed = orders.filter((o) => o.status === "completed").length
    const cancelled = orders.filter((o) => o.status === "cancelled").length

    return {
      pending,
      completed,
      cancelled,
    }
  }, [orders])

  // Filter orders
  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.filename.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesColor = colorFilter === "all" || order.color === colorFilter
      const matchesTab = order.status === activeTab

      return matchesSearch && matchesColor && matchesTab
    })
  }, [orders, searchQuery, colorFilter, activeTab])

  const handlePrint = (orderId: string) => {
    setOrders(orders.map((o) => (o.id === orderId ? { ...o, printed: true } : o)))
  }

  const handleDelete = (orderId: string) => {
    setOrders(orders.filter((o) => o.id !== orderId))
  }

  const handleCollect = (orderId: string) => {
    setOrders(orders.map((o) => (o.id === orderId ? { ...o, status: "completed" } : o)))
  }

  const handleUndoPrint = (orderId: string) => {
    setOrders(orders.map((o) => (o.id === orderId ? { ...o, printed: false } : o)))
  }

  const getTabTitle = () => {
    switch (activeTab) {
      case "pending":
        return "Pending Orders"
      case "completed":
        return "Completed Orders"
      case "cancelled":
        return "Cancelled Orders"
      default:
        return "Orders"
    }
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
      <div className="mx-auto max-w-7xl">
        <Card className="overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="flex justify-center px-6 pt-3">
              <TabsList className="mx-auto h-12 w-full max-w-2xl">
                <TabsTrigger value="pending" className="flex-1 text-base">
                  Pending
                  <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">
                    {stats.pending}
                  </span>
                </TabsTrigger>
                <TabsTrigger value="completed" className="flex-1 text-base">
                  Completed
                  <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">
                    {stats.completed}
                  </span>
                </TabsTrigger>
                <TabsTrigger value="cancelled" className="flex-1 text-base">
                  Cancelled
                  <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">
                    {stats.cancelled}
                  </span>
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="pending" className="m-0 p-6 pt-4 space-y-4">
              <div className="rounded-lg border bg-card">
                <div className="border-b bg-muted/50 px-4 py-3">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <h2 className="font-semibold">{getTabTitle()}</h2>

                      {!searchExpanded ? (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSearchExpanded(true)}>
                          <Search className="h-4 w-4" />
                        </Button>
                      ) : (
                        <div className="relative animate-in fade-in slide-in-from-left-2 duration-200">
                          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="Search..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="h-8 w-64 pl-9 pr-9"
                            autoFocus
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-1/2 h-8 w-8 -translate-y-1/2"
                            onClick={() => {
                              setSearchExpanded(false)
                              setSearchQuery("")
                            }}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}

                      {!filterExpanded ? (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setFilterExpanded(true)}>
                          <Filter className="h-4 w-4" />
                        </Button>
                      ) : (
                        <div className="flex items-center gap-2 animate-in fade-in slide-in-from-left-2 duration-200">
                          <div className="flex items-center gap-1 rounded-md border bg-background p-1">
                            <Button
                              variant={colorFilter === "all" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("all")}
                            >
                              All
                            </Button>
                            <Button
                              variant={colorFilter === "Color" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("Color")}
                            >
                              Color
                            </Button>
                            <Button
                              variant={colorFilter === "Black & White" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("Black & White")}
                            >
                              B&W
                            </Button>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setFilterExpanded(false)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>

                    <span className="text-sm text-muted-foreground">
                      Showing {filteredOrders.length} of {stats.pending}
                    </span>
                  </div>
                </div>
                <OrderList
                  orders={filteredOrders}
                  onPrint={handlePrint}
                  onDelete={handleDelete}
                  onCollect={handleCollect}
                  onUndoPrint={handleUndoPrint}
                />
              </div>
            </TabsContent>

            <TabsContent value="completed" className="m-0 p-6 pt-4 space-y-4">
              <div className="rounded-lg border bg-card">
                <div className="border-b bg-muted/50 px-4 py-3">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <h2 className="font-semibold">{getTabTitle()}</h2>

                      {!searchExpanded ? (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSearchExpanded(true)}>
                          <Search className="h-4 w-4" />
                        </Button>
                      ) : (
                        <div className="relative animate-in fade-in slide-in-from-left-2 duration-200">
                          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="Search..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="h-8 w-64 pl-9 pr-9"
                            autoFocus
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-1/2 h-8 w-8 -translate-y-1/2"
                            onClick={() => {
                              setSearchExpanded(false)
                              setSearchQuery("")
                            }}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}

                      {!filterExpanded ? (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setFilterExpanded(true)}>
                          <Filter className="h-4 w-4" />
                        </Button>
                      ) : (
                        <div className="flex items-center gap-2 animate-in fade-in slide-in-from-left-2 duration-200">
                          <div className="flex items-center gap-1 rounded-md border bg-background p-1">
                            <Button
                              variant={colorFilter === "all" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("all")}
                            >
                              All
                            </Button>
                            <Button
                              variant={colorFilter === "Color" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("Color")}
                            >
                              Color
                            </Button>
                            <Button
                              variant={colorFilter === "Black & White" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("Black & White")}
                            >
                              B&W
                            </Button>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setFilterExpanded(false)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>

                    <span className="text-sm text-muted-foreground">
                      Showing {filteredOrders.length} of {stats.completed}
                    </span>
                  </div>
                </div>
                <OrderList
                  orders={filteredOrders}
                  onPrint={handlePrint}
                  onDelete={handleDelete}
                  onCollect={handleCollect}
                  onUndoPrint={handleUndoPrint}
                />
              </div>
            </TabsContent>

            <TabsContent value="cancelled" className="m-0 p-6 pt-4 space-y-4">
              <div className="rounded-lg border bg-card">
                <div className="border-b bg-muted/50 px-4 py-3">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <h2 className="font-semibold">{getTabTitle()}</h2>

                      {!searchExpanded ? (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSearchExpanded(true)}>
                          <Search className="h-4 w-4" />
                        </Button>
                      ) : (
                        <div className="relative animate-in fade-in slide-in-from-left-2 duration-200">
                          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="Search..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="h-8 w-64 pl-9 pr-9"
                            autoFocus
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-1/2 h-8 w-8 -translate-y-1/2"
                            onClick={() => {
                              setSearchExpanded(false)
                              setSearchQuery("")
                            }}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}

                      {!filterExpanded ? (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setFilterExpanded(true)}>
                          <Filter className="h-4 w-4" />
                        </Button>
                      ) : (
                        <div className="flex items-center gap-2 animate-in fade-in slide-in-from-left-2 duration-200">
                          <div className="flex items-center gap-1 rounded-md border bg-background p-1">
                            <Button
                              variant={colorFilter === "all" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("all")}
                            >
                              All
                            </Button>
                            <Button
                              variant={colorFilter === "Color" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("Color")}
                            >
                              Color
                            </Button>
                            <Button
                              variant={colorFilter === "Black & White" ? "secondary" : "ghost"}
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setColorFilter("Black & White")}
                            >
                              B&W
                            </Button>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setFilterExpanded(false)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>

                    <span className="text-sm text-muted-foreground">
                      Showing {filteredOrders.length} of {stats.cancelled}
                    </span>
                  </div>
                </div>
                <OrderList
                  orders={filteredOrders}
                  onPrint={handlePrint}
                  onDelete={handleDelete}
                  onCollect={handleCollect}
                  onUndoPrint={handleUndoPrint}
                />
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  )
}
